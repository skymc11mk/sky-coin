# Sky Coin — Minecraft 1.12.2 (Forge)

Adds a single item, **Sky Coin**, with no crafting recipe, no world
generation, no abilities, and a max stack size of 64. Obtain it only
with `/give @p skycoin:sky_coin 64` or through a quest mod
(FTB Quests, Better Questing) reward.

## Project layout

```
src/main/java/com/skycoin/mod/
  SkyCoinMod.java        - @Mod entry point, pre-init/init events
  ModItems.java           - defines and registers the Sky Coin item
  proxy/CommonProxy.java  - server-safe no-op proxy
  proxy/ClientProxy.java  - binds the item model (client only)
src/main/resources/
  mcmod.info                                 - mod metadata
  pack.mcmeta                                - resource pack metadata
  assets/skycoin/textures/items/sky_coin.png - 16x16 item texture
  assets/skycoin/models/item/sky_coin.json   - item model
  assets/skycoin/lang/en_US.lang             - English name
  assets/skycoin/lang/ar_SA.lang             - Arabic name
```

## Building in GitHub Codespaces (no local PC required)

1. Push this folder to a GitHub repo (or upload the zip and create a
   repo from it), then open it in a Codespace.
2. Make sure the Codespace has **Java 8** available:
   ```
   sudo apt-get update && sudo apt-get install -y openjdk-8-jdk
   sudo update-alternatives --config java   # pick Java 8
   ```
3. ForgeGradle 2.3 (used by 1.12.2) needs an old Gradle. Generate a
   matching wrapper once, then always build through it:
   ```
   gradle wrapper --gradle-version 4.9
   ./gradlew build
   ```
   (If your Codespace has no system `gradle` at all, install one
   temporarily with `sdk install gradle 4.9` via
   [SDKMAN](https://sdkman.io/), just to bootstrap the wrapper — after
   that `./gradlew` is self-contained.)
4. The very first build downloads and deobfuscates Minecraft
   1.12.2 — this can take several minutes. Be patient.
5. When it finishes, the jar is at:
   ```
   build/libs/skycoin-1.0.0.jar
   ```
   Copy that file into your `mods/` folder (PojavLauncher's mods
   folder for 1.12.2 Forge works the same as desktop).

## Notes

- No crafting recipe file exists anywhere in the project — this is
  intentional and required, not an oversight.
- The item is never referenced by any loot table, chest, or village
  structure file, so it cannot appear in world generation.
- `Item` has no NBT, no `onItemRightClick` override, no durability,
  and is not enchantable.
