package com.skycoin.mod.proxy;

/**
 * Server/common proxy. No client-only rendering code runs here,
 * so a dedicated server never touches item model classes.
 */
public class CommonProxy {

    public void registerItemRenders() {
        // Intentionally empty on the common/server side.
    }
}
