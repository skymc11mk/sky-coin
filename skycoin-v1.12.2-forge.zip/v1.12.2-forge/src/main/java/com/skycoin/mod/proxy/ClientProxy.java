package com.skycoin.mod.proxy;

import com.skycoin.mod.ModItems;
import com.skycoin.mod.SkyCoinMod;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.model.ModelLoader;

/**
 * Client-only proxy. Binds the item model/texture. Never runs on a
 * dedicated server.
 */
public class ClientProxy extends CommonProxy {

    @Override
    public void registerItemRenders() {
        ModelLoader.setCustomModelResourceLocation(
                ModItems.SKY_COIN,
                0,
                new ModelResourceLocation(
                        new ResourceLocation(SkyCoinMod.MODID, "sky_coin"),
                        "inventory"
                )
        );
    }
}
