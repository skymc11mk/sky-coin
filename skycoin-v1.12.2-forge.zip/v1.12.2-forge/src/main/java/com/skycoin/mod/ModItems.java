package com.skycoin.mod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

/**
 * Holds and registers the single item added by this mod: Sky Coin.
 *
 * Sky Coin is a plain currency item:
 *  - stack size 64 (default net.minecraft.item.Item behaviour, set
 *    explicitly for clarity/future-proofing)
 *  - no ItemStack NBT, no Item.onItemRightClick override, no
 *    enchantability, no durability
 *  - not added to any furnace/loot/village/chest generation table —
 *    it is simply never referenced by any of those systems
 *  - added to the Miscellaneous creative tab only so it can be found
 *    in creative mode; this has no effect on survival obtainability
 */
public final class ModItems {

    public static final Item SKY_COIN = new Item()
            .setUnlocalizedName("skycoin.sky_coin")
            .setRegistryName(SkyCoinMod.MODID, "sky_coin")
            .setMaxStackSize(64)
            .setCreativeTab(CreativeTabs.MISC);

    private ModItems() {
    }

    /** Called from FMLPreInitializationEvent, both sides. */
    public static void registerItems() {
        ForgeRegistries.ITEMS.register(SKY_COIN);
    }
}
