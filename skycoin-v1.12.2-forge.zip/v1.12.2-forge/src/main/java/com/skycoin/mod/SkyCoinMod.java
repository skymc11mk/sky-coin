package com.skycoin.mod;

import com.skycoin.mod.proxy.CommonProxy;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

/**
 * Sky Coin
 *
 * A minimal currency-only item mod for Minecraft Forge 1.12.2.
 *
 * The mod registers exactly one item, "Sky Coin", intended to be
 * distributed only through commands (e.g. /give) or quest mods such
 * as FTB Quests / Better Questing. It has:
 *  - a max stack size of 64 (the default, explicitly set for clarity)
 *  - no crafting recipe
 *  - no world/loot/chest/village generation
 *  - no NBT, durability, enchantments, or right-click behavior
 */
@Mod(modid = SkyCoinMod.MODID, name = SkyCoinMod.NAME, version = SkyCoinMod.VERSION)
public class SkyCoinMod {

    public static final String MODID = "skycoin";
    public static final String NAME = "Sky Coin";
    public static final String VERSION = "1.0.0";

    @Instance(MODID)
    public static SkyCoinMod instance;

    @SidedProxy(clientSide = "com.skycoin.mod.proxy.ClientProxy",
                serverSide = "com.skycoin.mod.proxy.CommonProxy")
    public static CommonProxy proxy;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ModItems.registerItems();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.registerItemRenders();
    }
}
